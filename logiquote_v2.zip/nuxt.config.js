export default {
  target: "static",
  buildModules: [],
  css: [],
  build: {},
};