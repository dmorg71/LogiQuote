<template>
  <div class="min-h-screen bg-gray-100 p-4">
    <div class="max-w-2xl mx-auto bg-white shadow-md rounded-xl p-6">
      <h1 class="text-2xl font-bold mb-4 text-center">LogiQuote - Final Expense Quoting</h1>
      <p class="mb-4 text-center text-gray-600">Enter health conditions or medications below:</p>
      <form @submit.prevent="getQuotes">
        <textarea v-model="entry" placeholder='e.g. "COPD, oxygen, smoker"' class="w-full border rounded p-2 mb-4"></textarea>
        <div class="flex justify-center">
          <button class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Get Quotes</button>
        </div>
      </form>
      <div v-if="quotes.length" class="mt-6">
        <h2 class="text-xl font-semibold mb-2">Quote Results:</h2>
        <ul class="list-disc pl-6">
          <li v-for="quote in quotes" :key="quote.carrier">
            {{ quote.carrier }} – {{ quote.plan }} – ${{ quote.price }}/month
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      entry: "",
      quotes: [],
    };
  },
  methods: {
    getQuotes() {
      // Placeholder logic for now
      const conditions = this.entry.toLowerCase();
      if (conditions.includes("copd") && conditions.includes("oxygen")) {
        this.quotes = [
          { carrier: "CICA", plan: "Standard", price: "62.43" },
          { carrier: "Gerber", plan: "GI", price: "85.16" },
          { carrier: "Corebridge", plan: "GI", price: "98.83" },
        ];
      } else if (conditions.includes("gabapentin") && conditions.includes("insulin")) {
        this.quotes = [
          { carrier: "Royal Neighbors", plan: "Level", price: "94.75" },
          { carrier: "GTL", plan: "Graded", price: "92.00" },
          { carrier: "Gerber", plan: "GI", price: "85.16" },
        ];
      } else {
        this.quotes = [
          { carrier: "LifeShield", plan: "Level", price: "49.84" },
          { carrier: "Family Benefit", plan: "Level", price: "53.75" },
          { carrier: "American Amicable", plan: "Level", price: "59.74" },
        ];
      }
    }
  }
}
</script>

<style>
body {
  font-family: system-ui, sans-serif;
}
</style>