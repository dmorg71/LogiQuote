
<template>
  <div style="text-align:center; margin-top: 100px;">
    <h1>🧠 LogiQuote is Live!</h1>
    <p>Welcome to your Nuxt.js powered quoting app.</p>
  </div>
</template>
