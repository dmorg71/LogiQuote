
<template>
  <div style="text-align: center; padding-top: 100px;">
    <h1>🎉 Access Granted</h1>
    <p>Welcome to <strong>LogiQuote</strong> – Final Expense Quoting Made Easy.</p>
    <p style="margin-top: 2rem;">More features coming soon...</p>
  </div>
</template>
